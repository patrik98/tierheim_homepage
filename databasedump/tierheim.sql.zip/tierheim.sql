-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Erstellungszeit: 13. Apr 2018 um 10:21
-- Server-Version: 10.1.26-MariaDB
-- PHP-Version: 7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `tierheim`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `map_aktivitaet`
--

CREATE TABLE `map_aktivitaet` (
  `aktid` int(11) NOT NULL,
  `termin` datetime DEFAULT NULL,
  `bezeichnung` varchar(100) DEFAULT NULL,
  `nutzer` int(11) DEFAULT NULL,
  `tier` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `nutzer`
--

CREATE TABLE `nutzer` (
  `nutzerid` int(11) NOT NULL,
  `vname` varchar(100) DEFAULT NULL,
  `nname` varchar(100) DEFAULT NULL,
  `gebdat` date DEFAULT NULL,
  `passwort` varchar(255) DEFAULT NULL,
  `email` varchar(60) DEFAULT NULL,
  `strasse` varchar(50) DEFAULT NULL,
  `hausnr` varchar(10) DEFAULT NULL,
  `plz` varchar(15) DEFAULT NULL,
  `ort` varchar(50) DEFAULT NULL,
  `spende` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `spende`
--

CREATE TABLE `spende` (
  `spendeid` int(11) NOT NULL,
  `zahlungsart` varchar(100) DEFAULT NULL,
  `betrag` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tier`
--

CREATE TABLE `tier` (
  `tierid` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `gebdat` date DEFAULT NULL,
  `tierart` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tierart`
--

CREATE TABLE `tierart` (
  `tierartid` int(11) NOT NULL,
  `bezeichnung` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `map_aktivitaet`
--
ALTER TABLE `map_aktivitaet`
  ADD PRIMARY KEY (`aktid`),
  ADD KEY `nutzer` (`nutzer`),
  ADD KEY `tier` (`tier`);

--
-- Indizes für die Tabelle `nutzer`
--
ALTER TABLE `nutzer`
  ADD PRIMARY KEY (`nutzerid`),
  ADD KEY `spende` (`spende`);

--
-- Indizes für die Tabelle `spende`
--
ALTER TABLE `spende`
  ADD PRIMARY KEY (`spendeid`);

--
-- Indizes für die Tabelle `tier`
--
ALTER TABLE `tier`
  ADD PRIMARY KEY (`tierid`),
  ADD KEY `tierart` (`tierart`);

--
-- Indizes für die Tabelle `tierart`
--
ALTER TABLE `tierart`
  ADD PRIMARY KEY (`tierartid`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `map_aktivitaet`
--
ALTER TABLE `map_aktivitaet`
  MODIFY `aktid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT für Tabelle `nutzer`
--
ALTER TABLE `nutzer`
  MODIFY `nutzerid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT für Tabelle `spende`
--
ALTER TABLE `spende`
  MODIFY `spendeid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT für Tabelle `tier`
--
ALTER TABLE `tier`
  MODIFY `tierid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT für Tabelle `tierart`
--
ALTER TABLE `tierart`
  MODIFY `tierartid` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints der exportierten Tabellen
--

--
-- Constraints der Tabelle `map_aktivitaet`
--
ALTER TABLE `map_aktivitaet`
  ADD CONSTRAINT `map_aktivitaet_ibfk_1` FOREIGN KEY (`nutzer`) REFERENCES `nutzer` (`nutzerid`),
  ADD CONSTRAINT `map_aktivitaet_ibfk_2` FOREIGN KEY (`tier`) REFERENCES `tier` (`tierid`);

--
-- Constraints der Tabelle `nutzer`
--
ALTER TABLE `nutzer`
  ADD CONSTRAINT `nutzer_ibfk_1` FOREIGN KEY (`spende`) REFERENCES `spende` (`spendeid`);

--
-- Constraints der Tabelle `tier`
--
ALTER TABLE `tier`
  ADD CONSTRAINT `tier_ibfk_1` FOREIGN KEY (`tierart`) REFERENCES `tierart` (`tierartid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
